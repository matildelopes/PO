package pt.tecnico.uilib.text;

interface Properties {
  public static final String WRITE_INPUT = "writeInput";
  
  public static final String BOTH_CHANNELS = "both";
  
  public static final String INPUT_CHANNEL = "in";
  
  public static final String OUTPUT_CHANNEL = "out";
  
  public static final String LOG_CHANNEL = "log";
}


/* Location:              C:\Users\tomgl\OneDrive\Documents\Hava\po-uilib (1).jar!\pt\tecnic\\uilib\text\Properties.class
 * Java compiler version: 15 (59.0)
 * JD-Core Version:       1.1.3
 */