package prr.core.exception;

public class DoubleClientException extends Exception{
    private String _id;
    public DoubleClientException(String id) {
        _id = id;
    }
    public String getId() {
        return _id;
    }

}
