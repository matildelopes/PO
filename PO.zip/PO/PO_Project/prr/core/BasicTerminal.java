package prr.core;

public class BasicTerminal extends Terminal {
    /**
     * Contruct BasicTerminal
     * @param id
     * @param client
     */
    public BasicTerminal(String id, Client client){
        super(id,client);
    }
}
