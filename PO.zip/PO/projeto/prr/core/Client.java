package prr.core;

import prr.core.Terminal;
import prr.core.ClientLevel;

import java.util.TreeMap;

// FIXME define contructor(s)
public class Client{
    private String _key;
    private String _name;
    private int _taxNumber;
    private ClientLevel _level;
    private boolean _receiveNotifications;
    private TreeMap<String , Terminal> _owner;
    
    public Client(String name, String key, int taxNumber, ClientLevel level){
        _name = name;
        _key = key;
        _taxNumber = taxNumber;
        _level = level;

    }
}