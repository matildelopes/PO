package prr.core;

import java.io.Serializable;
import java.util.*;



// FIXME add more import if needed (cannot import from pt.tecnico or prr.app)

/**
 * Abstract terminal.
 */
abstract public class Terminal implements Serializable /* FIXME maybe addd more interfaces */{

  /** Serial number for serialization. */
  private static final long serialVersionUID = 202208091753L;
  
  // FIXME define attributes
  // FIXME define contructor(s)
    private String _id;
    private String _mode;
    private double _debt;
    private double _payments;
    private TreeMap<String,Terminal> _friends;
    private final prr.core.Client _client;


    
    public Terminal(String id, String mode, double debt, double payments, prr.core.Client client){
        _id = id;
        _mode = mode;
        _debt = debt;
        _payments = payments;
        _client = client;

    } 

  // FIXME define methods
  
  /**
   * Checks if this terminal can end the current interactive communication.
   *
   * @return true if this terminal is busy (i.e., it has an active interactive communication) and
   *          it was the originator of this communication.
   **/
  public boolean canEndCurrentCommunication() {
    return true;
      // FIXME add implementation code
  }
  
  /**
   * Checks if this terminal can start a new communication.
   *
   * @return true if this terminal is neither off neither busy, false otherwise.
   **/
  public boolean canStartCommunication() {
      return true;
    // FIXME add implementation code
  }
}
