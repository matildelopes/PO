



def main():
    #print(agrupa_por_chave([("a", 8), ("b", 9), ("a", 3),("b",7), ("c",44)]))


    
if __name__ == '__main__':
    main()