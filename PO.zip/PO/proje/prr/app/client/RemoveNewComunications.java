package prr.app.client;

import prr.core.Network;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

public class RemoveNewComunications extends Command<Network> {

    RemoveNewComunications(Network receiver){
    super("Remover Comunicações novas", receiver);
    }

    @Override
    protected final void execute() {
        int ident = integerField("identificador");
        _receiver.removenewComunication(ident);

        }


        }

}


