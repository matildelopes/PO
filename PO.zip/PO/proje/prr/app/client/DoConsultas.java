package prr.app.client;

import prr.app.exception.DuplicateClientKeyException;
import prr.core.Communication;
import prr.core.Network;
import prr.core.exception.DuplicateKeyException;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;

public class DoConsultas extends Command<Network>{
    DoConsultas(Network receiver){
        super("Melhor comunicação", receiver);


}
    @Override
    protected final void execute() throws CommandException {
        _receiver.doConsults(ident);
    }
