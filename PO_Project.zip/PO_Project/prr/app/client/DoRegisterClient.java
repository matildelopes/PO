package prr.app.client;

import prr.core.Network;
import prr.app.exception.DuplicateClientKeyException;
import prr.core.exception.DoubleClientException;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
//FIXME add more imports if needed

/**
 * Register new client.
 */
class DoRegisterClient extends Command<Network> {

  DoRegisterClient(Network receiver) {
    super(Label.REGISTER_CLIENT, receiver);
    //FIXME add command fields
    addStringField("clientKey", Message.key());
    addStringField("clientName", Message.name());
    addIntegerField("clientTaxId", Message.taxId());
  }
  
  @Override
  protected final void execute() throws CommandException {
    //FIXME implement command
    try{
      _receiver.registerClient(stringField("clientKey"), stringField("clientName"), integerField("clientTaxId"));
    }catch( DoubleClientException e){
      throw new DuplicateClientKeyException(e.getId());
    }



  }
}
