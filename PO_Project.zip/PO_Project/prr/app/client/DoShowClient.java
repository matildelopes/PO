package prr.app.client;

import prr.app.exception.DuplicateClientKeyException;
import prr.core.Network;
import prr.app.exception.UnknownClientKeyException;
import prr.core.exception.ClientDoNotExist;
import prr.core.exception.DoubleClientException;
import pt.tecnico.uilib.menus.Command;
import pt.tecnico.uilib.menus.CommandException;
//FIXME add more imports if needed

/**
 * Show specific client: also show previous notifications.
 */
class DoShowClient extends Command<Network> {

  DoShowClient(Network receiver) {
    super(Label.SHOW_CLIENT, receiver);
    //FIXME add command fields
    addStringField("clientKey", Message.key());

  }
  
  @Override
  protected final void execute() throws CommandException {
    //FIXME implement command
    try {
      _display.addLine(_receiver.showClient("clientKey"));
      _display.display();

    } catch (ClientDoNotExist e) {
      throw new UnknownClientKeyException(e.getKey());
    }
  }
}