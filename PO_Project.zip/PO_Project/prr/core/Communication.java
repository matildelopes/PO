package prr.core;

public class Communication {
    private int _id;
}
