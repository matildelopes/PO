package prr.core;

import prr.core.Terminal;
import prr.core.ClientLevel;

import java.util.TreeMap;

// FIXME define contructor(s)
public class Client{
    private String _key;
    private String _name;
    private int _taxNumber;
    private ClientLevel _level;
    private boolean _receiveNotifications;
    private TreeMap<String , Terminal> _lstTerminals;
    private double _payments;

    private double _debts;
    
    public Client(String key, String name, int taxNumber){
        _name = name;
        _key = key;
        _taxNumber = taxNumber;
        _level = ClientLevel.NORMAL;
        _receiveNotifications = true;
        _lstTerminals = new TreeMap<String , Terminal>();
        _payments = 0.0;
        _debts = 0.0;

    }

    public String toStrNotif( ) {
        if (_receiveNotifications) {
            return "YES";
        }
        return "NO";
    }

    public void addTerminal(Terminal t){
        _lstTerminals.put(t.getId(),t);
    }

    public String toString(){
        return "CLIENT|" + _key + "|"+ _name + "|"+ _taxNumber + "|"+ _level + "|"+ toStrNotif() + "|"+ _lstTerminals + "|" + Math.round(_payments) + Math.round(_debts);
    }



    public String getKey() {
        return _key;
    }
    public String getName() {
        return _name;
    }
    public int getTaxNumber() {
        return _taxNumber;
    }
    public ClientLevel getLevel() {return _level; }
    public boolean getReceiveNot() {return _receiveNotifications; }
    public TreeMap<String , Terminal> getLstTerminals(){return _lstTerminals;}
}

