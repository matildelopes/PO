package prr.core;

public class FancyTerminal extends Terminal{

    public FancyTerminal(String id, Client client){
        super(id, client);
    }
}
