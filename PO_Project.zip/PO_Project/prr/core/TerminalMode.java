package prr.core;

public enum TerminalMode {
    SILENCE,
    IDLE,
    OFF,
    BUSY;
}
