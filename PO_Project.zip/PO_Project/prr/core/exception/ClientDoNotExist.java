package prr.core.exception;

public class ClientDoNotExist extends Exception{
    private String _id;
    public ClientDoNotExist(String id) {
        _id = id;
    }
    public String getKey() {
        return _id;
    }

}

